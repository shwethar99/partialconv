from __future__ import print_function
#from sklearn import datasets
import matplotlib.pyplot as plt
import math
import numpy as np
import cv2

# Import helper functions
from mlfromscratch.deep_learning import NeuralNetwork
from mlfromscratch.utils import train_test_split, to_categorical, normalize
from mlfromscratch.utils import get_random_subsets, shuffle_data, Plot
from mlfromscratch.utils.data_operation import accuracy_score
from mlfromscratch.deep_learning.optimizers import StochasticGradientDescent, Adam, RMSprop, Adagrad, Adadelta
from mlfromscratch.deep_learning.loss_functions import CrossEntropy, SquareLoss
from mlfromscratch.utils.misc import bar_widgets
from mlfromscratch.deep_learning.layers import Dense, Dropout, Conv2D, Flatten, Activation, MaxPooling2D, UpSampling2D
from mlfromscratch.deep_learning.layers import AveragePooling2D, ZeroPadding2D, BatchNormalization, RNN



def main():

    #----------
    # Conv Net
    #----------

    optimizer = Adam(learning_rate=0.0001)
    #learning_rate=0.00005

    #data = datasets.load_digits()
    #X = data.data
    #y = data.target
    #y =np.zeros((128,128))

    # Convert to one-hot encoding
    #y = to_categorical(y.astype("int"))

    #X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, seed=1)

    # Reshape X to (n_samples, channels, height, width)
    #X_train = X_train.reshape((-1,1,8,8))
    #X_test = X_test.reshape((-1,1,8,8))
    X_train= cv2.imread("/content/drive/MyDrive/test_images/image1.png")
    X_train = cv2.resize(X_train, (128,128))
    X_train= X_train.reshape((1,3,128,128))
    y_train= cv2.imread("/content/drive/MyDrive/test_images/label1.jpg")
    y_train = cv2.resize(y_train, (128,128))
    y_train= y_train.reshape((1,3,128,128))

    clf = NeuralNetwork(optimizer=optimizer, loss=SquareLoss)
    def up_block(clf, filters):
      clf.add(UpSampling2D(size=(2,2)))
      clf.add(Conv2D(n_filters=filters,filter_shape=(3,3),stride=1,padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.25))
      clf.add(BatchNormalization())
      clf.add(Conv2D(n_filters=filters, filter_shape=(3,3), stride=1, padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.25))
      clf.add(BatchNormalization())

    def down_block(clf, filters):
      clf.add(Conv2D(n_filters=filters,filter_shape=(3,3),stride=1,padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.25))
      clf.add(BatchNormalization())
      clf.add(Conv2D(n_filters=filters, filter_shape=(3,3), stride=1, padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.25))
      clf.add(BatchNormalization())
      clf.add(MaxPooling2D(pool_shape=(2,2), stride=2, padding='same'))

    def bottleneck(clf, filters):
      clf.add(Conv2D(n_filters=filters,filter_shape=(3,3),stride=1,padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.4))
      clf.add(BatchNormalization())
      clf.add(Conv2D(n_filters=filters, filter_shape=(3,3), stride=1, padding='same'))
      clf.add(Activation('relu'))
      #clf.add(Dropout(0.4))
      clf.add(BatchNormalization())

    '''
    clf.add(Conv2D(n_filters=16, filter_shape=(3,3), stride=1, input_shape=(3,128,128), padding='same'))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.25))
    clf.add(BatchNormalization())
    clf.add(Conv2D(n_filters=32, filter_shape=(3,3), stride=1, padding='same'))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.25))
    clf.add(BatchNormalization())
    clf.add(Flatten())
    clf.add(Dense(256))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.4))
    clf.add(BatchNormalization())
    clf.add(Dense(10))
    clf.add(Activation('softmax'))
    '''

    f=[16, 32, 64, 128, 256, 512]
    clf.add(Conv2D(n_filters=3, filter_shape=(3,3), stride=1, input_shape=(3,128,128), padding='same'))
    #clf.add(Activation('relu'))
    #clf.add(BatchNormalization())
    down_block(clf, f[0])
    down_block(clf, f[1])
    down_block(clf, f[2])
    down_block(clf, f[3])
    down_block(clf,f[4])

    bottleneck(clf, f[5])

    up_block(clf, f[4])
    up_block(clf, f[3])
    up_block(clf, f[2])
    up_block(clf, f[1])
    up_block(clf, f[0])

    clf.add(Conv2D(n_filters=3, filter_shape=(3,3),padding='same'))
    clf.add(Activation('relu'))
    #clf.add(BatchNormalization())
    print()
    clf.summary(name="UNet")

    clf.load_weights()
    #clf.display_weights()

    y_pred,train_err, val_err = clf.fit(X_train, y_train, n_epochs=150, batch_size=1)
    #print(y_pred)
    y_pred= y_pred.reshape((128,128,3))
    
    #plt.imsave("/content/drive/My Drive/y_pred1.jpg", y_pred)
    y_pred= y_pred * 255.0
    y_pred = y_pred.astype('uint8')
    
 
    cv2.imwrite("/content/drive/My Drive/training_stage_images/y_pred_bp1.jpg", y_pred )
    '''
    fig = plt.figure()
    fig.subplots_adjust(hspace=0.4, wspace=0.4)

    ax = fig.add_subplot(1, 2, 1)
    ax.imshow(y_pred)
    '''
     

if __name__ == "__main__":
    main()
